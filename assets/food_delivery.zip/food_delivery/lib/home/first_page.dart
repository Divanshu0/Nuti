import 'dart:js_util';

import 'package:flutter/material.dart';
import 'package:food_delivery/home/second_page.dart';

class FirstPage extends StatefulWidget {
  const FirstPage({Key? key}) : super(key: key);

  @override
  State<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  @override
  Widget build(BuildContext context) {
    return new SplashScreen(
      seconds: 10,
      navigateAfterSeconds: new HomeScreen(),// Where to navigate after 10 secs
      image: new Image.asset('assets/images/flutter_logo.png'),
      photoSize: 200,
      loaderColor: Colors.white,
      styleTextUnderTheLoader : const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold, color: Colors.white),
      loadingText: new Text('Loading...'),
      gradientBackground: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          Colors.lightBlue,
          Colors.indigo
        ],
      ),
    );
  }
}
// Container(
// child: GestureDetector(
// onTap: (){
// Navigator.push(context, MaterialPageRoute(builder: (context)=> SecondPage()));
// },
// ),
// margin: EdgeInsets.only(top: 340,bottom: 341,left: 79,right: 78),
// decoration: BoxDecoration(
// image: DecorationImage(image: AssetImage("assets/firstpage.jpg")),
// ),
// ),


// return MaterialApp(
// home: SafeArea(
// child: Scaffold(
// backgroundColor: Colors.white,
// body: Container(
// margin: EdgeInsets.only(top: 340,bottom: 341,left: 79,right: 78),
// decoration: BoxDecoration(
// image: DecorationImage(image: AssetImage("assets/firstpage.jpg")),
// )
// ),
// ),
// ),
// );