import 'package:flutter/material.dart';

class MainFoodPage extends StatefulWidget {
  const MainFoodPage({Key? key}) : super(key: key);

  @override
  State<MainFoodPage> createState() => _MainFoodPageState();
}

class _MainFoodPageState extends State<MainFoodPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: SafeArea(
        child: Drawer(
          child: Container(
            margin: EdgeInsets.only(top: 5),
              child: Column(
                children: [
                    GestureDetector(onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> MainFoodPage()));
                    },
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            boxShadow:[
                              BoxShadow(
                                color: Colors.black12,
                              )
                            ]
                        ),
                        alignment: Alignment.topLeft,
                        padding: EdgeInsets.all(16),
                        height: 50,
                        width: 300,
                        child: Text("User Profile",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                      ),
                    ),
                  SizedBox(
                    height: 5,
                  ),
                  GestureDetector(onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> MainFoodPage()));
                  },
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          boxShadow:[
                            BoxShadow(
                              color: Colors.black12,
                            )
                          ]
                      ),
                      alignment: Alignment.topLeft,
                      padding: EdgeInsets.all(16),
                      height: 50,
                      width: 300,
                      child: Text("Help",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    ),
                  ),
                ],
              )
        ),
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.orange[800],
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(height:40,width:40,decoration: BoxDecoration(color:Colors.black12,borderRadius:BorderRadius.circular(25) ),
                child:  IconButton(onPressed: () {}, icon: Icon(Icons.favorite_border,color: Colors.white,size: 15)
                ),
              ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(width: 40,height: 40,decoration: BoxDecoration(borderRadius:BorderRadius.circular(25),color: Colors.black12 ),
              child: IconButton(onPressed: () {}, icon: Icon(Icons.shopping_cart,color: Colors.white,size: 15)
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(width: 40,height: 40,decoration: BoxDecoration(borderRadius:BorderRadius.circular(25),color: Colors.black12 ),
              child: IconButton(onPressed: () {}, icon: Icon(Icons.notifications,color: Colors.white,size: 15)
              ),
            ),
          ),
        ],
      ),
    );
  }
}
