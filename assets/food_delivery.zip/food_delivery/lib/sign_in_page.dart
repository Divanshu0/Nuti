import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery/home/main_food_page.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(
        child: Container(
          height:MediaQuery.of(context).size.height,
          child: Scaffold(
            backgroundColor: Colors.grey[350],
            body:SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children:[
                  Container(

                    margin: EdgeInsets.only(top: 30),
                    height: 100,
                    width: 300,
                    decoration: BoxDecoration(
                      image:DecorationImage(image: AssetImage("assets/image.jpg")),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: const Text(
                      "Welcome Back",
                      style: TextStyle(color: Colors.black, fontSize: 30,fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Text(
                    "Login to your existing Nuti Account",
                    style: TextStyle(color: Colors.black38, fontSize: 15,fontWeight: FontWeight.normal),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(left: 15,right: 15,top: 20,bottom: 50),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),color: Colors.white,
                      ),
                      height: 325,
                      width: 400,
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(6.0),
                                child: Text("Sign In",style: TextStyle(
                                  fontSize: 15,fontWeight:FontWeight.bold,
                                ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 3.0,left: 3.0),
                                child: Text("Enter your email and password",style: TextStyle(
                                    fontSize: 13,fontWeight:FontWeight.bold,color: Colors.grey),
                                ),
                              ),
                              SizedBox(

                                  height: 15
                              ),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Username",style: TextStyle(
                                        fontWeight: FontWeight.bold
                                    ),
                                    ),
                                    SizedBox(

                                      height: 10,
                                    ),
                                    TextField(
                                      decoration: InputDecoration(
                                          fillColor: Colors.grey[200],
                                          filled: true,
                                          hintText: "Email id",
                                          border: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(20),borderSide: BorderSide.none)),
                                    ),
                                    SizedBox(

                                      height: 20,
                                    ),
                                    Text("Password",style: TextStyle(
                                        fontWeight: FontWeight.bold
                                    ),),
                                    SizedBox(

                                      height: 10,
                                    ),
                                    TextField(
                                      obscureText: true,
                                      decoration: InputDecoration(
                                        fillColor: Colors.grey[200],
                                        filled: true,
                                        hintText: "Enter your password",
                                        border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(20),borderSide: BorderSide.none),
                                      ),
                                    ),
                                      SizedBox(

                                                height: 12,
                                      ),
                                                  GestureDetector(
                                                    onTap: (){
                                                      Navigator.push(context, MaterialPageRoute(builder: (context)=> MainFoodPage()));
                                                    },
                                                    child: Text("Lost your Password?",style: TextStyle(
                                                      fontSize: 15,fontWeight:FontWeight.bold,
                                                    ),),
                                                  ),

                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                   Column(
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=> MainFoodPage()));
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Colors.orange[800],shape:RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)
                          )
                          ),
                          child: Container(
                            alignment: Alignment.center,
                            padding: EdgeInsets.all(16),
                            height: 50,
                            width: 300,
                            child: Text("Sign In",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                          ),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Container(
                          margin: EdgeInsets.only(bottom: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              RichText(text: TextSpan(
                                text: "Don't have an Account?",style: TextStyle(
                                fontWeight: FontWeight.normal,color: Colors.black,fontSize: 12
                              ),children: [

                                TextSpan(text: " Register",recognizer: TapGestureRecognizer()..onTap = (){Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            MainFoodPage()));
                                },style: TextStyle(fontWeight: FontWeight.normal,fontSize: 15,color: Colors.orange[800]))
                              ],
                              ),)
                            ],
                          ),
                        )
                      ],
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
      );
  }
}