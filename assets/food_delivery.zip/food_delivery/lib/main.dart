import 'package:flutter/material.dart';
import 'package:food_delivery/home/first_page.dart';
import 'package:food_delivery/home/main_food_page.dart';
import 'package:food_delivery/home/second_page.dart';
import 'package:food_delivery/sign_in_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        initialRoute: "first_page",
        routes: {"first_page":(
        context) => const FirstPage(),
          "second_page":(
              context) => SecondPage(),
        "sign_in_page": (
        context) => const SignInPage(),
        "main_food_page": (
        context) => const MainFoodPage(),
        });
  }
}

